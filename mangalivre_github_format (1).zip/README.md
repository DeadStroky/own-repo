# Manga Livre (pt-BR)

Extensão para o site [Manga Livre](https://mangalivre.tv) para uso no Tachiyomi/Mihon.

- Idioma: Português (Brasil)
- NSFW: Parcial (violência gráfica em algumas obras)
- Suporte à leitura, busca, capítulos, scroll infinito, conteúdo adulto

---
**Extensão de uso pessoal — não afiliada ao MangaLivre.tv.**