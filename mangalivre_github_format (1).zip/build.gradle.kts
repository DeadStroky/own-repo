version = "1.0.0"

apply(plugin = "tachiyomi.extension")

dependencies {
    implementation(project(":multisrc:madara"))
}